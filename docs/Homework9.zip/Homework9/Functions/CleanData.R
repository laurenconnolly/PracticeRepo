# --------------------------------------
# FUNCTION clean_data
# required packages: none
# description:
# inputs:
# outputs:
########################################
clean_data <- function(x=data){
  if (any(x$scientificName=="")){
    cleanData <- x[-which(x$scientificName==""), ]
  } else {
    cleanData <- data
  }
} # end of function clean_data
# --------------------------------------

#year <- 2015
#path <- paste0("~/Documents/CompBiology/Homework9/", year)
#path
