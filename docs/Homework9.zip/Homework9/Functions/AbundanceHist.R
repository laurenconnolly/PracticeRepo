# --------------------------------------
# FUNCTION abundance_hist
# required packages: none
# description:
# inputs:
# outputs:
########################################
abundance_hist <- function(){ 
    ggplot(data=plot) +
      aes(x=a_vec) +
      geom_histogram(binwidth=100, fill="blue", color="black")
    setwd("~/Documents/CompBiology/Homework9")
    ggsave(filename = "AbundanceHistogram.png",
           path = "~/Documents/CompBiology/Homework9/Plots/")
  }
 # end of function abundance_hist
# --------------------------------------
