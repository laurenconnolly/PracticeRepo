# --------------------------------------
# FUNCTION load_functions
# required packages: none
# description:
# inputs:
# outputs:
########################################
load_functions <- function(){
  source("Functions/CleanData.R")
  source("Functions/FindYear.R")
  source("Functions/FindAbundance.R")
  source("Functions/FindSpecies.R")
  source("Functions/FindRegression.R")
  source("Functions/PlotRegression.R")
  source("Functions/SpeciesHist.R")
  source("Functions/AbundanceHist.R")
  source("Functions/CalcRegstats.R")
  source("Functions/StoreDfs.R")
  source("Functions/SaveCleandata.R")
}


# end of function load_functions

