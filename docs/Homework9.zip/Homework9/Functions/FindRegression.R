# --------------------------------------
# FUNCTION find_regression
# required packages: none
# description:
# inputs:
# outputs:
########################################
find_regression <- function(x=abundance, y=species){
  c(x,y)
} # end of function find_regression
# --------------------------------------
