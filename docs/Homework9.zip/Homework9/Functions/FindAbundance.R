# --------------------------------------
# FUNCTION find_abundance
# required packages: none
# description:
# inputs:
# outputs:
########################################
find_abundance <- function(x=cleanData){
  c(a_vec, nrow(x))
} # end of function find_abundance
# --------------------------------------

