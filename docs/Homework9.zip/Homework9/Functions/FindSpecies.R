# --------------------------------------
# FUNCTION find_species
# required packages: none
# description:
# inputs:
# outputs:
########################################
find_species <- function(x=cleanData){
  s <- length(unique(x$scientificName))
  c(s_vec, s)
} # end of function find_species
# --------------------------------------

