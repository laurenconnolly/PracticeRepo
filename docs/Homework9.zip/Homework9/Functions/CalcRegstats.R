# --------------------------------------
# FUNCTION calc_regstats
# required packages: none
# description:
# inputs:
# outputs:
########################################
calc_regstats <- function(){
  stats <- lm(s_vec ~ a_vec, data=plot)
  summary <- summary(stats)
  reg_stats <- data.frame(summary$coefficients[2,1], summary$coefficients[2,4], summary$r.squared)
  colnames(reg_stats) <- c("slope" ,"p-value", "R-squared value")
  return(reg_stats)
} # end of function calc_regstats
# --------------------------------------

