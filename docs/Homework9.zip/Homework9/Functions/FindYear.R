# --------------------------------------
# FUNCTION find_year
# required packages: none
# description:
# inputs:
# outputs:
########################################
find_year <- function(x=countDataFile){
  year <- stringr::str_extract(x, pattern="countdata\\.(\\d{4})")
  y_vec <- c(y_vec, year)
  return(y_vec)
} # end of function find_year
# --------------------------------------

