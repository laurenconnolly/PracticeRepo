# --------------------------------------
# FUNCTION store_dfs
# required packages: none
# description:
# inputs:
# outputs:
########################################
store_dfs <- function(){
  colnames(plot) <- c("Abundace", "Species", "Year")
  write.csv(plot, "~/Documents/CompBiology/Homework9/Outputs/SummaryStatistics.csv")
  write.csv(reg_stats, "~/Documents/CompBiology/Homework9/Outputs/RegressionStatistics.csv")
} # end of function store_dfs
# --------------------------------------

