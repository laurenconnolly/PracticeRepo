# --------------------------------------
# FUNCTION get_data
# required packages: stringr
# description:
# inputs:
# outputs:
########################################
for(folder in allData){
    countDataFile <- list.files(path=folder, pattern="countdata", full.names=TRUE)
    #data <- read.csv(countDataFile)
    #year <- stringr::str_extract(countDataFile, "countdata\\.(\\d{4})")
    #countData[[paste0(year)]] <- countDataFile
    print(countDataFile)
  }
# end of function get_data
# --------------------------------------
