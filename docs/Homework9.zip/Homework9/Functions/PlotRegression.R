# --------------------------------------
# FUNCTION plot_regression
# required packages: none
# description:
# inputs:
# outputs:
########################################
plot_regression <- function(){
  ggplot(data=plot) +
    aes(x=plot[,1], y=plot[,2]) +
    geom_point() +
    geom_smooth(method=lm)
  #setwd("~/Documents/CompBiology/Homework9")
  ggsave(filename = "RegressionPlot.png",
         path = "~/Documents/CompBiology/Homework9/Plots/")
} # end of function plot_regression
# --------------------------------------

