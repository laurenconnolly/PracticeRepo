# --------------------------------------
# FUNCTION species_hist
# required packages: none
# description:
# inputs:
# outputs:
########################################
species_hist <- function(){ 
  ggplot(data=plot) +
    aes(x=s_vec) +
    geom_histogram(binwidth=5, fill="blue", color="black")
  setwd("~/Documents/CompBiology/Homework9")
  ggsave(filename = "SpeciesHistogram.png",
         path = "~/Documents/CompBiology/Homework9/Plots/")
} # end of function species_hist
# --------------------------------------

