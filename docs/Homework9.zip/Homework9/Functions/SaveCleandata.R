# --------------------------------------
# FUNCTION save_cleandata
# required packages: none
# description:
# inputs:
# outputs:
########################################
save_cleandata <- function(df=cleanData, x=i){
  year <- y_vec[x]
  write.csv(df, paste0("~/Documents/CompBiology/Homework9/CleanedData/", year,".csv"))
} # end of function save_cleandata
# --------------------------------------
