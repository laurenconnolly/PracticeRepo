##Lauren Connolly
##MainScript.R

##Loading libraries ----

library(pracma)
library(pryr)
library(devtools)
library(stringr)
library(tidyverse)
install_github("ngotelli/upscaler")
library(upscaler)

##Setting up project folders and log file ----
add_folder()
set_up_log()

##Data ----
setwd("~/Documents/CompBiology/Homework9")
source("Functions/LoadFunctions.R")
load_functions()

allData <- list.dirs(path="OriginalData/NEON_count-landbird", recursive=FALSE)
plot <- data.frame()
reg_stats <- data.frame()
s_vec <- c()
a_vec <- c()
y_vec <- c()

for(i in 1:10){
  setwd(allData[i])

  countDataFile <- list.files(pattern="countdata", full.names=TRUE)
  data <- read.csv(countDataFile)
  
  cleanData <- clean_data()
  save_cleandata()
  y_vec <- find_year()
  a_vec <- find_abundance()
  s_vec <- find_species()

  setwd("~/Documents/CompBiology/Homework9")
}
plot <- data.frame(a_vec, s_vec, y_vec)
reg_stats <- calc_regstats()
plot_regression()
species_hist()
abundance_hist()
store_dfs()






